import time
import random
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import (
    NoSuchElementException, 
    StaleElementReferenceException, 
    TimeoutException
)
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from dotenv import load_dotenv

load_dotenv()

USERNAME = os.getenv('INSTA_USERNAME', 'xyz') 
PASSWORD = os.getenv('INSTA_PASSWORD', 'xyz') 
TARGET_CELEB_USERNAME = os.getenv('TARGET_CELEB', 'xyz')
FOLLOWER_COUNT_TO_PROCESS = int(os.getenv('FOLLOWER_COUNT', 1000))

class InstagramStoryViewer:
    def __init__(self):
        options = Options()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-notifications")
        options.add_experimental_option("detach", True)
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 15)
        self.processed_profiles = set()

    def random_sleep(self, min_time=2, max_time=5):
        time.sleep(random.uniform(min_time, max_time))

    def login(self):
        try:
            self.driver.get('https://www.instagram.com/accounts/login/')
            self.random_sleep(3, 6)
            username_field = self.wait.until(EC.presence_of_element_located((By.NAME, 'username')))
            username_field.send_keys(USERNAME)
            password_field = self.driver.find_element(By.NAME, 'password')
            password_field.send_keys(PASSWORD + Keys.RETURN)
            self.random_sleep(7, 10)
            print("✅ Successfully logged in")
        except TimeoutException:
            raise Exception("❌ Login page failed to load")

    def open_celeb_followers(self):
        try:
            self.driver.get(f'https://www.instagram.com/{TARGET_CELEB_USERNAME}/')
            self.random_sleep(4, 7)
            followers_link = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, '//a[contains(@href,"/followers/")]'))
            )
            followers_link.click()
            self.random_sleep(3, 5)
            print(f"✅ Opened {TARGET_CELEB_USERNAME}'s followers list")
        except TimeoutException:
            raise Exception("❌ Could not open followers list")

    def is_profile_private(self):
        try:
            self.driver.find_element(By.XPATH, '//h2[contains(text(), "This Account is Private")]')
            return True
        except NoSuchElementException:
            return False

    def open_story(self, profile_link):
        if profile_link in self.processed_profiles:
            print(f"⏭️ Skipping already processed profile: {profile_link}")
            return False

        try:
            print(f"📍 Visiting follower profile: {profile_link}")
            self.driver.get(profile_link)
            self.random_sleep(3, 6)

            if self.is_profile_private():
                print(f"🔒 Skipping private profile: {profile_link}")
                return False

            print(f"🔍 Checking for story on {profile_link}")
            story_selectors = [
                '//div[contains(@class, "x1lliihq")]',  # Updated profile story ring class
                '//button[contains(@aria-label, "Story")]',
                '//div[@role="button"]//img[contains(@alt, "profile picture")]/ancestor::div[2]'
            ]

            story_element = None
            for selector in story_selectors:
                try:
                    story_element = self.wait.until(
                        EC.element_to_be_clickable((By.XPATH, selector))
                    )
                    print(f"🎬 Story detected with selector: {selector}")
                    break
                except TimeoutException:
                    print(f"🔎 Selector {selector} found no story yet...")
                    continue

            if not story_element:
                print(f"❌ No story available for {profile_link}, moving to next profile")
                return False

            print(f"👀 Opening story for {profile_link}")
            story_element.click()
            self.random_sleep(5, 8)
            print(f"✅ Story viewed for {profile_link}")
            return True

        except Exception as e:
            print(f"❗ Error opening story on {profile_link}: {e}")
            return False

    def process_followers(self, followers):
        print(f"🚀 Starting to process {len(followers)} followers of {TARGET_CELEB_USERNAME}...")
        if not followers:
            print("❌ No followers to process. Stopping.")
            return

        for i, profile_link in enumerate(followers[:FOLLOWER_COUNT_TO_PROCESS], 1):
            try:
                if not profile_link:
                    print(f"⚠️ Empty profile link at position {i}, skipping")
                    continue
                
                print(f"👤 Processing follower {i}/{FOLLOWER_COUNT_TO_PROCESS}: {profile_link}")
                if not self.open_story(profile_link):
                    continue
                self.processed_profiles.add(profile_link)
                self.random_sleep(3, 6)

            except Exception as e:
                print(f"❗ Unexpected error on follower {i}: {e}")
                continue

    def run(self):
        try:
            self.login()
            self.open_celeb_followers()
            followers = self.load_followers(FOLLOWER_COUNT_TO_PROCESS)
            if not followers:
                print("❌ No followers loaded. Exiting.")
                return

            print("✅ Follower loading complete. Starting processing...")
            self.process_followers(followers)
            print(f"🏁 Completed: {len(self.processed_profiles)} stories viewed successfully")
        except Exception as e:
            print(f"❌ Fatal error: {e}")
        finally:
            self.driver.quit()

if __name__ == '__main__':
    bot = InstagramStoryViewer()
    bot.run()